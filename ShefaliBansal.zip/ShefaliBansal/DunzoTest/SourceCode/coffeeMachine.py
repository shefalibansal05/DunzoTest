MAX_QUANTITY_OF_INGREDIENT = 500
class Machine():
    def __init__(self, outlets=3, totalItemsQuantity={}, beveragesInfo={}):
        self.outlets = outlets
        self.totalItemsQuantity = totalItemsQuantity
        self.beveragesInfo = beveragesInfo
        #beveragesInfo is dictionary of key - bev name and value - dict of ingredient and its quantity required to make it

    def displayItemsQuantity(self):
        print("Items Quantity as follows: ")
        for item, quantity in self.totalItemsQuantity.items():
            print(item, ' is ', quantity)

    def refillItem(self, item):
        self.totalItemsQuantity[item] = MAX_QUANTITY_OF_INGREDIENT
        print("Refilling done")

    def isValidBeverage(self, beverageName):
        return beverageName in self.beveragesInfo.keys()

    def areValidIngredients(self, ingredients):
        for reqItem in ingredients.keys():
            if not reqItem in self.totalItemsQuantity.keys():
                return reqItem
        return

    def makeBeverage(self, beverageName):
        if not self.isValidBeverage(beverageName):
            print(beverageName, " is not available in this coffee machine.")
            return
        ingredients = self.beveragesInfo[beverageName]
        areValidIngredients = self.areValidIngredients( ingredients )
        if areValidIngredients is not None:
            print(beverageName, " cannot be prepared because because", areValidIngredients," is not available with coffee machine.")
            return

        leftValue = {key: self.totalItemsQuantity[key] - ingredients.get(key, 0) for key in self.totalItemsQuantity.keys()}
        if any(v < 0 for v in leftValue.values()):
            refillItems = []
            for item, quantity in leftValue.items():
                if quantity < 0:
                    refillItems.append(item)

            for item in refillItems:
                print("Beverage ", beverageName, "cannot be prepared because item ", item, " is not sufficient.")
                print("Refilling required for item ", item)
                self.refillItem(item)
            self.totalItemsQuantity = {key: self.totalItemsQuantity[key] - ingredients.get(key, 0) for key in self.totalItemsQuantity.keys()}
        else:
            self.totalItemsQuantity = leftValue
        print(beverageName," is prepared.")
        return
