import coffeeMachine
import os

def initializeMachine():
    with open(os.path.dirname(__file__)+"\\..\\Inputs\\machine.json", "r") as inputData:
        inputDict = eval(inputData.read())
        machineOutlets = int(inputDict.get("machine").get("outlets").get("count_n"))
        totalItemsQuantity = inputDict.get("machine").get("total_items_quantity")
        beveragesInfo= inputDict.get("machine").get("beverages")
        machine = coffeeMachine.Machine(machineOutlets, totalItemsQuantity, beveragesInfo)
        return machine

def getOrders():
    with open(os.path.dirname(__file__)+"\\..\\Inputs\\BeverageRequirement.txt", "r") as inputData:
        ordersInput = inputData.read().splitlines()
        orders = []
        for order in ordersInput:
            orders.append(order.split(","))
        return orders

def processOrders(machine, order):
    print("Processing order ", ",".join(order))
    for beverage in order:
        machine.makeBeverage(beverage.strip())
    print("------")


def main():
    machine = initializeMachine()
    print("Machine is ready with the below ingredients- ")
    machine.displayItemsQuantity()
    print("------")
    orders = getOrders()
    for order in orders:
        processOrders(machine, order)


main()
